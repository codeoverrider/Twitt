console.log("Bot is Starting");
var Twit = require('twit');
var config=require('./config');
var T = new Twit(config);

var tweet = {
	status:'#Googlisation Hello from the other side'}
T.post('statuses/update',tweet,tweeted);
function tweeted(err,data,response){
	if(err){
		console.log("Somethings Wrong");

	}
	else{
		console.log("It Worked");
	}
}