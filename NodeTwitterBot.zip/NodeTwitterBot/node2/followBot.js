console.log(" The Follow Bot is Starting");
var Twit = require('twit');
var config=require('./config');
var T = new Twit(config);

var stream = T.stream('user');

stream.on('follow',followed);

function followed(eventMsg)
{
	console.log('SomeOne followed you. Let me tweet for you :D ')
	var name=eventMsg.source.name;
	var screenName=eventMsg.source.screen_name;
	tweetItNow('@'+screenName+" Hi, Thank you for following me.  ");
}


function tweetItNow(txt)
{
	
	var tweet = {
		status:txt
				}
	T.post('statuses/update',tweet,tweeted);
	function tweeted(err,data,response){
		if(err){
			console.log("Somethings Wrong");

		}
		else{
			console.log("It Worked");
		}
	}
}