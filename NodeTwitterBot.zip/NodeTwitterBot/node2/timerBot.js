console.log("Bot is Starting");
var Twit = require('twit');
var config=require('./config');
var T = new Twit(config);

tweetItNow();
setInterval(tweetItNow,1000*20)

function tweetItNow()
{
	var r = Math.floor(Math.random()*100);


	var tweet = {
		status:'here is a Random Number '+r+' #Googlisation Hello from the other side'}
	T.post('statuses/update',tweet,tweeted);
	function tweeted(err,data,response){
		if(err){
			console.log("Somethings Wrong");

		}
		else{
			console.log("It Worked");
		}
	}
}