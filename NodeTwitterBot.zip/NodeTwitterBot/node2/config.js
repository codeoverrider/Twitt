module.exports={
consumer_key:         'EUyLnOKCKQpGDKbTlz5neG4AN',
consumer_secret:      'm4S4w6ptqv97fi68up7l7aPLQrHz399LeNlgEHnUgGfxeZwtgS',
access_token:         '3049812536-UwjpzkiT8LSNKmJMb6zB5At4qHDbPHEvEFJ3EDa',
access_token_secret:  'uuk1K52Im9HyJaOzyJzI5iO1uD1VMFOvygYKu1u9eXfrd',
};